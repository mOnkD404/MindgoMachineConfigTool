#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QTcpServer>
#include <QTcpSocket>
#include <QAbstractTableModel>
#include <QElapsedTimer>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    connect(&m_server, &QTcpServer::newConnection, this, &MainWindow::newConnection);
    m_server.listen(QHostAddress::Any, 20000);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::newConnection()
{
    QTcpSocket *skt = m_server.nextPendingConnection();
    if(!skt->isOpen())
        return;


    QByteArray recvArray;
    QElapsedTimer timer;
    timer.start();
    while(skt->isReadable() && timer.elapsed() < 1000)
    {
        if (skt->bytesAvailable() > 0)
        {
            QByteArray array = skt->read(skt->bytesAvailable());
            qDebug()<<array.size()<<"data recv"<<array;
            recvArray.append(array);
        }
    }

}


int TableModel::rowCount(const QModelIndex &parent) const
{
    return m_data.size();
}
int TableModel::columnCount(const QModelIndex &parent) const
{
    return 2;
}
QVariant TableModel::data(const QModelIndex &index, int role) const
{
    if(role == Qt::DisplayRole)
    {
        if(index.column() == 0)
        {
            return QVariant::fromValue(m_data.at(index.row()).first);
        }
        if(index.column() == 1)
        {
            return QVariant::fromValue(m_data.at(index.row()).second);
        }
    }
    return QVariant();
}
void TableModel::addRow(int index, char dat)
{
    m_data.append(qMakePair(index, dat));
    while(m_data.size() > 100)
    {
        m_data.pop_front();
    }
}
